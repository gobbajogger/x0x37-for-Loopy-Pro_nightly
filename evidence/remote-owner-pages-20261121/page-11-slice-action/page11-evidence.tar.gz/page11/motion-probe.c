/* SPDX-License-Identifier: GPL-3.0-only */
#include <assert.h>
#include <stdio.h>
#include "motion.h"

static int value;
static int base(void *ctx, int target, int voice, int index) {
    (void)ctx;
    assert(target == 3 && voice == 0 && index == 0);
    return value;
}
static void apply(void *ctx, int target, int voice, int index, int raw) {
    (void)ctx; (void)target; (void)voice; (void)index; (void)raw;
}
int main(void) {
    static lane_t lanes[NLANE];
    motion_t motion;
    motion_init(&motion, lanes);
    motion.base = base;
    motion.apply = apply;
    const int slot = motion_alloc(lanes, 2, 4, 3, 0, 0);
    assert(slot >= 0 && motion_find(lanes, 1, 4, 3, 0, 0) == -1);
    value = 20;
    motion_req_rec(&motion, slot);
    for (int s = 0; s < NSTEPS; s++) assert(lanes[slot].val[s] == MOT_NONE);
    motion_step(&motion, 4, 2, 1, 2, 16);
    motion_step(&motion, 4, 2, 2, 3, 16);
    motion_step(&motion, 4, 2, 3, 4, 16);
    assert(lanes[slot].val[1] == 20 && lanes[slot].val[2] == MOT_NONE);
    value = 80;
    motion_req_rec(&motion, slot);
    motion_step(&motion, 4, 2, 4, 5, 16);
    const unsigned int expected[] = {20, 40, 60, 80};
    for (int s = 0; s < NSTEPS; s++) {
        assert(lanes[slot].val[s] == (s >= 1 && s <= 4 ? expected[s-1] : MOT_NONE));
    }
    /* An actual pattern change discards a request queued for the departed pattern. */
    motion_req_rec(&motion, slot);
    motion_step(&motion, 4, 1, 5, 6, 16);
    motion_step(&motion, 4, 2, 5, 6, 16);
    assert(lanes[slot].val[5] == MOT_NONE);
    puts("{\"part\":4,\"patternIndex\":2,\"parameter\":[3,0,0],\"setBeforeFirmwareStep\":false,\"steps2Through5\":[20,40,60,80],\"queuedRecordAfterLeavingPattern\":false}");
}
