import asyncio, functools, hashlib, importlib.util, json, sys, threading
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from playwright.async_api import async_playwright, expect

here=Path(__file__).resolve().parent
root=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else here/'candidate/web/product-site'
mode=sys.argv[1]
def read_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

if mode == 'green':
    test=read_module('journey',root.parents[1]/'tests/product-remote/pattern_lock_journey.py')
async def draft_state(page):
    menu=page.locator('details.overflow')
    if not await menu.evaluate('e=>e.open'):await menu.locator('summary').click()
    async with page.expect_download() as event:await page.locator('#draft-save').click()
    output=json.loads(Path(await (await event.value).path()).read_bytes())
    await menu.locator('summary').click()
    return output

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self,*args):pass
async def main():
    server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    rows=[]
    async with async_playwright() as p:
        browser=await p.chromium.launch(chromium_sandbox=True)
        for width,height in [(844,390)] if mode=='red' else [(1440,900),(844,390),(390,844)]:
            page=await browser.new_page(viewport={'width':width,'height':height},accept_downloads=True)
            errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
            await page.goto(f'http://127.0.0.1:{server.server_port}/remote/',wait_until='domcontentloaded')
            await page.wait_for_function("typeof document.querySelector('[data-engine]').onclick==='function'")
            await page.locator('[data-engine="breaks"]').click()
            await expect(page.locator('[data-break-step="0"]')).to_be_visible()
            if mode=='green':
                await page.locator('[data-break-view="slices"]').click()
                await expect(page.locator('[data-break-step="0"]')).to_be_focused()
            await page.locator('[data-view="patterns"]').click()
            await page.locator('[data-launch-part="4"][data-pattern="2"]').click()
            await page.locator('[data-view="roll"]').click()
            await page.locator('#break-locks').click()
            await page.locator('#velocity [data-lane-step="7"]').press('ArrowDown')
            control=page.locator('[data-break-view="slices"]')
            if mode=='red':
                await control.press('Enter')
                await expect(page.locator('[data-break-step="0"]')).to_be_visible()
                row={'name':await control.inner_text(),'focusedStep':await page.evaluate("document.activeElement?.getAttribute('data-break-step')")}
                rows.append(row)
                (here/'receipts/red.json').write_text(json.dumps({'browser':browser.version,'baseline':row,'errors':errors},indent=2)+'\n')
                assert row['name']=='Slice 1–32' and row['focusedStep']=='7',row
            else:
                before=await draft_state(page)
                assert before['launch'][4]==2 and next(r for r in before['patternLocks'] if r['catalogId']==1153 and r['pattern']==2)['values'][7]==126
                await test.check_slice_range(page,draft_state)
                after=await draft_state(page)
                await control.click()
                await expect(page.locator('[data-break-step="7"]')).to_be_focused()
                row={'viewport':[width,height],'label':await control.inner_text(),'slice':after['breakSequence']['slices'][7],'stepFocus':await page.evaluate("document.activeElement.dataset.breakStep"),'patternLock':subrow(before),'unchangedMotion':after['motion']==before['motion'],'unchangedLaunch':after['launch']==before['launch'],'pageErrors':errors}
                row['toolbar']=await control.evaluate('''e => [...e.parentNode.querySelectorAll('button')].map(b => {const r=b.getBoundingClientRect();return {label:b.textContent,width:r.width,height:r.height,inside:r.left>=0&&r.top>=0&&r.right<=innerWidth&&r.bottom<=innerHeight,hit:document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)===b};})''')
                assert all(b['inside'] and b['hit'] and min(b['width'],b['height'])>=40 for b in row['toolbar']),row['toolbar']
                # A second visit to an already-open Slices panel should retain its existing edit controls.
                step_zero=page.locator('[data-break-step="0"]')
                await step_zero.evaluate('e=>window.sliceFieldBeforeClick=e')
                await control.click()
                assert await step_zero.evaluate('e=>e===window.sliceFieldBeforeClick')
                # Release an intentionally delayed sample manifest after the user has moved focus away.
                await page.locator('[data-break-view="notes"]').click()
                entered=asyncio.Event(); resume=asyncio.Event()
                async def delayed(route):
                    entered.set()
                    await resume.wait()
                    await route.continue_()
                await page.route('**/sample-contract.json',delayed)
                await control.press('Enter')
                await asyncio.wait_for(entered.wait(),5)
                sentinel=page.locator('#connect')
                await sentinel.focus()
                resume.set()
                await expect(step_zero).to_be_visible()
                await expect(sentinel).to_be_focused()
                row['lateLoadKeptFocus']=True
                assert not errors,errors
                rows.append(row)
            await page.close()
        if mode=='green':(here/'receipts/green.json').write_text(json.dumps({'browser':browser.version,'checks':rows},indent=2)+'\n')
        await browser.close()
    server.shutdown()
    print(json.dumps(rows))
def subrow(state):
    row=next(r for r in state['patternLocks'] if r['catalogId']==1153 and r['pattern']==2)
    return [row['catalogId'],row['pattern']+1,8,row['values'][7]]
asyncio.run(main())
