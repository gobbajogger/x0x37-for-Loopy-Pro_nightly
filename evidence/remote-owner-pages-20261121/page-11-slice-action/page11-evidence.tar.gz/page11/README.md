# BREAK slice assignment and free-motion ownership

The original owner PDF on page 11 places “Slice 1-32”, Generator, Motion, Step locks and Review draft below sixteen numbered steps. Step 1 is highlighted in the drawn example. At product commit `3241ee2f3ee03255ad1f7d5921c4b813280ce2ac`, Generator, Step locks and Review draft already have working routes. The independent change in `slice-action.patch` gives the existing Slices control the displayed name “Slice 1–32” and keyboard/pointer access to the corresponding assignment. The existing Notes route is retained. The toolbar occupies different positions across responsive layouts.

The patch changes two product files, their two manifest entries, and a regression in the existing pattern-lock browser journey. Opening the action after editing lane step 8 focuses slice step 8. Within the Slices panel it returns to the last focused slice step. Initially it focuses step 1. Reopening an already mounted panel keeps its existing fields and preview instance. If the sample contract loads after the user moves elsewhere, their newer focus is preserved. The sixteen assignments continue using the existing shared local Draft BREAK sequence. The Level-lock edit retains its independent part and pattern ownership.

## Browser evidence

`receipts/red.json` records the prior button text and the absence of a focused slice field after ordinary keyboard activation. `receipts/green.json` records the pointer, keyboard and export results by viewport using Chromium 151.0.7922.34 with its normal sandbox. The journey selects BREAK P03, sets step 8 Level to raw 126, opens Slice 1–32 and chooses 32. It verifies the other slice assignments and all pattern-lock, launch and MIAMI Motion data against an export taken before the slice edit. It checks the initial step, all slice options, second activation, hit-testing of each toolbar action, focus after delayed loading, and page errors. The stepFocus field is zero-based.

`receipts/source.json` records source hashes. `receipts/applies-on` records the newer commit on whose index the patch also passed an apply check. `receipts/correction-regression.log` records eight passing pre-existing source-event cases. The focused browser check imports the same new assertion used in the existing pattern-lock journey.

## Native free Motion

At firmware `468744971720a81a536308e3bd84bd8766a5ed0f`, `firmware/src/app/ui.c` routes a moved engine knob through `motion_touch` while playing. It reads the actual part pattern from `seq.ppat[part]`, finds or allocates that parameter’s lane and, while recording, calls `engine_motion_rec`. In `firmware/src/seq/motion.c`, the following sequencer step samples the real base value. A short gap between touched steps is interpolated. Changing the active pattern discards its departing lane’s queued event.

The host C probe in `motion-probe.c` links the stock firmware motion implementation with a test base-value callback. Its receipt shows BREAK P03 values 20, 40, 60 and 80 on steps 2–5 and correct cancellation across a pattern switch. It exercises the firmware motion algorithm on a host, with no audio or hardware output. The Remote’s admitted runtime frame reports playing/stopped/unavailable. Its existing local free-motion Draft identifies Bass B / MIAMI / CARRIER / WAVE. A genuine BREAK recording route still requires the active BREAK pattern and step, movement of the actual parameter under transport/record, and the owned lane result. The slice action and the disconnected Level-lock editor do not establish this native workflow.

## Reproduction

Run from a clean exact-base checkout with the qualification environment sourced. Set `P11` to the directory containing this note and the patch. Run the baseline check first. Exit 1 with button text Slices and focusedStep null is the expected baseline failure.

```sh
python "$P11/run.py" red "$PWD/web/product-site"
git apply "$P11/slice-action.patch"
python "$P11/run.py" green "$PWD/web/product-site"
node tests/product-workspace/app-correction-regression.mjs
node --check web/product-site/remote/app.mjs
```

From the stock firmware checkout:

```sh
cc -std=c11 -Wall -Wextra -Werror -I firmware/src/seq "$P11/motion-probe.c" firmware/src/seq/motion.c -o "$P11/motion-probe"
"$P11/motion-probe"
```
