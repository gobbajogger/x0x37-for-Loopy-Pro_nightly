import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {runFixture} from './before-site/reference/screens/runner.mjs';
import {paintFrame} from './before-site/reference/screens/render.mjs';
const dir='qawork/before-site/reference/screens',out='qawork/native';
fs.mkdirSync(out,{recursive:true});
const source=JSON.parse(fs.readFileSync(path.join(dir,'states.json')));
const expected=new Map(fs.readFileSync('delivery/tests/firmware-reference/native-rgb.tsv','utf8').trim().split('\n').map(s=>s.split('\t')));
const states=['view-08-part-04-voice-00-page-00','view-08-part-04-voice-00-page-01','view-08-part-04-voice-00-page-02','view-01-part-04-voice-00-page-00','chicago-wave-valid-lock'];
const seen={};
for (const fil of [0,2]){
 const mod=await WebAssembly.compile(fs.readFileSync(path.join(dir,source.modules[fil])));
 const wanted=states.filter(name=>source.states.find(r=>r[0]===name)[3]===fil);
 const done={};
 try {runFixture(mod,0,(id,bytes)=>{
  if(!wanted.includes(id)) return;
  let rgba;
  paintFrame({createImageData:(w,h)=>({data:new Uint8Array(w*h*4)}),putImageData:f=>{rgba=f.data}},bytes);
  const rgb=Buffer.alloc(240*240*3);
  for(let i=0;i<240*240;i++)rgb.set(rgba.subarray(4*i,4*i+3),3*i);
  const digest=createHash('sha256').update(rgb).digest('hex');
  if(digest!==expected.get(id))throw Error('native mismatch '+id+': '+digest);
  seen[id]=digest;
  fs.writeFileSync(path.join(out,id+'.ppm'),Buffer.concat([Buffer.from('P6\n240 240\n255\n'),rgb]));
  if(wanted.every(k=>seen[k]))throw done;
 });}catch(e){if(e!==done)throw e;}
}
if(Object.keys(seen).length!==states.length)throw Error('incomplete native reference');
fs.writeFileSync(path.join(out,'verified.json'),JSON.stringify({firmware:source.firmware,oracles:seen},null,2)+'\n');
console.log(JSON.stringify(seen));
