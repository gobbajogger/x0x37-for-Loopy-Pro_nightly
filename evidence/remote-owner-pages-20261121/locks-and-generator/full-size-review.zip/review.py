"""Independent review of the owner page 3/17 and page 11 normal editor routes."""
import argparse, asyncio, hashlib, json, runpy, sys
from pathlib import Path
from playwright.async_api import async_playwright, expect

ROOT=Path.cwd().resolve()
server=runpy.run_path(str(ROOT/'delivery/tests/product-remote/envelope-browser.py'))['server']
h=lambda b:hashlib.sha256(b).hexdigest()
core=runpy.run_path(str(ROOT/'delivery/tests/product-remote/funkybeats-browser.py'))
CENSUS="""e=>{const b=e.getBoundingClientRect(), s=getComputedStyle(e), c=document.elementFromPoint(b.x+b.width/2,b.y+b.height/2), label=e.labels?.[0];
return {tag:e.tagName, role:e.getAttribute('role'), name:(e.getAttribute('aria-label')||label?.textContent||e.innerText||'').trim(),
 value:e.value, shown:e.getAttribute('aria-valuetext'), rect:[b.x,b.y,b.width,b.height], hit:c===e||e.contains(c),
 fg:s.color,bg:s.backgroundColor, font:s.fontSize, indicator:label?.querySelector('svg')?.outerHTML, data:e.dataset.breakSetting};}"""
async def menu(p,name):
    det=p.locator('.overflow')
    if not await det.evaluate('e=>e.open'): await det.locator('summary').click()
    await p.locator('[data-view="'+name+'"]').click()
    if await det.evaluate('e=>e.open'): await det.locator('summary').click()

async def capture(p,out,name,stats):
    overflow=await p.evaluate("()=>[document.documentElement.scrollWidth, innerWidth]")
    assert overflow[0] <= overflow[1], (name,overflow)
    await p.screenshot(path=out/(name+'.png'),timeout=30000)
    stats['states'].append(name)

async def check(b,site,out,origin,width,height,after):
    dest=out/str(width);dest.mkdir(parents=True,exist_ok=True)
    ctx=await b.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
    p=await ctx.new_page();errs=[];p.on('pageerror',lambda e:errs.append(str(e)));p.set_default_timeout(20000)
    stats={'states':[],'errors':errs,'size':[width,height]}
    await p.goto(origin+'/remote/')
    try:
        await expect(p.locator('#velocity [data-lane-step]').first).to_be_visible(timeout=20000)
    except Exception:
        diagnostics=await p.evaluate('''async()=>{let error;try{await import('./app.mjs')}catch(e){error=String(e.stack||e)}return {error,body:document.body.innerText.slice(-500),busy:document.querySelector('main')?.getAttribute('aria-busy')}}''')
        print('startup diagnostics',errs,diagnostics,flush=True)
        raise
    await p.locator('[data-engine="chicago"]').click()
    await p.locator('[data-view="patterns"]').click()
    await p.locator('[data-launch-part="2"][data-pattern="0"]').click()
    await menu(p,'locks')
    await capture(p,dest,'motion-entry',stats)
    cycle=p.locator('#lane-param')
    if after:
        picker=p.get_by_role('combobox',name='Choose lock target')
        await expect(picker).to_be_visible();await picker.scroll_into_view_if_needed()
        stats['picker']=await picker.evaluate(CENSUS)
        stats['pitchRows']=await p.locator('#roll-scroll').evaluate('el=>{const row=parseFloat(getComputedStyle(el).getPropertyValue(\'--row\'));return {height:el.clientHeight,row,whole:Math.floor(el.clientHeight/row)}}')
        stats['pickerPoints']=await picker.evaluate('''el=>{const b=el.getBoundingClientRect(),points=[[.1,.1],[.1,.9],[.5,.5],[.9,.1],[.9,.9]];
         return points.map(([x,y])=>{const h=document.elementFromPoint(b.x+b.width*x,b.y+b.height*y);return {x,y,hit:h===el||el.contains(h),node:h?.id||h?.tagName}})}''')

        stats['choices']=await picker.locator('option:not(:disabled)').all_text_contents()
        assert len(stats['choices'])==20
        assert stats['picker']['rect'][2]>=40 and stats['picker']['rect'][3]>=40,stats['picker']
        assert all(x['hit'] for x in stats['pickerPoints']),stats['pickerPoints']
        await picker.select_option('4098')
        cutoff=p.locator('#velocity [data-lane-step]').nth(15)
        await cutoff.press('ArrowUp')
        await expect(cutoff).to_have_attribute('aria-valuetext','26%')
        document=await core['draft_state'](p)
        row=next(r for r in document['patternLocks'] if r['catalogId']==4098 and r['pattern']==0)
        assert row['values'][15]==33,row
        stats['cutoff']={'raw':33,'visible':await cutoff.get_attribute('aria-valuetext')}
        await p.locator('#undo').click()
        await expect(cutoff).to_have_attribute('aria-valuetext','Unset')
        await picker.select_option('4099')  # Chicago Peak is a separate scalar from Cutoff.
        selected=p.locator('#velocity [data-lane-step]').nth(4)
        await expect(selected).to_have_attribute('aria-valuetext','Unset')
        await selected.press('ArrowUp')
        value=await selected.get_attribute('aria-valuetext')
        assert value and value!='Unset',value
        stats['stepValue']=value
        await p.locator('#undo').click()
        await expect(selected).to_have_attribute('aria-valuetext','Unset')
        await p.locator('#redo').click()
        await expect(selected).to_have_attribute('aria-valuetext',value)
        await selected.scroll_into_view_if_needed();stats['editedStep']=await selected.evaluate(CENSUS)
        await capture(p,dest,'selected-lock',stats)
        await picker.select_option('4113')
        for _ in range(4): await selected.press('ArrowUp')
        await expect(selected).to_have_attribute('aria-valuetext','COMPRESSOR')
        stats['longestLock']=await p.locator('#lane-value .lock-display').evaluate('''el=>{
         const range=document.createRange(); range.selectNodeContents(el);
         const a=range.getBoundingClientRect(),b=document.querySelector('#lane-param').getBoundingClientRect();
         const rect=r=>[r.x,r.y,r.width,r.height];
         return {text:el.innerText,value:rect(a),owner:rect(b),fits:a.x>=b.x-1 && a.right<=b.right+1 && a.top>=b.top-1 && a.bottom<=b.bottom+1};
        }''')
        await capture(p,dest,'compressor-lock',stats)

    else:
        stats['targetCount']=await p.get_by_role('combobox',name='Choose lock target').count()
    await p.locator('[data-engine="breaks"]').click()
    await p.locator('[data-view="patterns"]').click()
    await p.locator('[data-launch-part="4"][data-pattern="0"]').click()
    await p.locator('[data-view="roll"]').click()
    await p.locator('[data-break-view="slices"]').click()
    await capture(p,dest,'break-entry',stats)
    gen=p.get_by_role('button',name='Generator',exact=True)
    stats['generatorCount']=await gen.count()
    if after:
        await gen.click()
        pane=p.locator('#break-generator')
        await expect(pane.locator('[data-break-setting]')).to_have_count(11)
        await capture(p,dest,'break-generator',stats)
        fields=[]
        for f in await pane.locator('[data-break-setting]').all():
            await f.scroll_into_view_if_needed()
            fields.append(await f.evaluate(CENSUS))
        stats['generatorFields']=fields
        stats['generatorText']=await pane.inner_text()
        assert all(f['hit'] and f['name'] and f['rect'][2]>0 for f in fields),fields
        val=pane.locator('[data-break-setting="0"]')
        initial=await val.input_value()
        symbol=val.locator('xpath=ancestor::label[1]').locator('svg')
        graphic=lambda: symbol.evaluate('el=>el.outerHTML') if symbol else None
        svg_before=await graphic() if await symbol.count() else None
        await val.fill('72');await val.press('Tab');await expect(val).to_have_value('72')
        svg_after=await graphic() if await symbol.count() else None
        stats['changedGlyph']={'before':h(svg_before.encode()) if svg_before else None,'after':h(svg_after.encode()) if svg_after else None}
        document=await core['draft_state'](p)
        gr=next(r for r in document['breakSequence']['generators'] if r['pattern']==0)
        assert gr['settings'][0]==72,gr
        stats['savedGenerator']=gr

        await p.locator('#undo').click();await expect(val).to_have_value(initial)
        await p.locator('#redo').click();await expect(val).to_have_value('72')
        await p.locator('[data-view="sound"]').click()
        chance=p.locator('.break-sound-chance [data-break-setting="9"]')
        await expect(chance).to_be_visible()
        await chance.scroll_into_view_if_needed()
        stats['soundChance']=await chance.evaluate(CENSUS)
        await capture(p,dest,'break-sound',stats)
    assert not errs,errs
    (dest/'report.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2)+'\n')
    print(('after' if after else 'before'),width,height,len(stats['states']),'passed',flush=True)
    await ctx.close()

async def main():
    a=argparse.ArgumentParser();a.add_argument('site',type=Path);a.add_argument('out',type=Path);a.add_argument('--after',action='store_true');x=a.parse_args()
    with server(x.site.resolve()) as origin:
        async with async_playwright() as pw:
            b=await pw.chromium.launch(chromium_sandbox=True)
            try:
                for w,hgt in [(1440,900),(844,390),(390,844)]:
                    await check(b,x.site,x.out,origin,w,hgt,x.after)
            finally: await b.close()
if __name__=='__main__': asyncio.run(main())
