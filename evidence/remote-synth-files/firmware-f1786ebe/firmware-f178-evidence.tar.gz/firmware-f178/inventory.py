"""Read Git objects and bounded archive members. No extraction or original execution."""
from collections import Counter,defaultdict
from hashlib import sha256
from io import BytesIO
import csv,gzip,json,lzma,re,subprocess,sys,tarfile,zipfile
from pathlib import Path
from PIL import Image
d=Path(__file__).resolve().parent; repo=Path(sys.argv[1]).resolve()
firm='f1786ebec2616477163b62b029c7e77405a9c3de'
donor='f013ecc653f2b9f0006e976a1097250e9356ce14'
prior='49662e4d437421e686a6cc04b806cd0d700bab74'
conductor='74b50bdfe2e1d9ac7f22445cdf5ab3726bb85272'
def git(*v):return subprocess.check_output(['git','-C',str(repo),*v])
def obj(p,rev=firm):return git('show',rev+':'+p)
def oid(p,rev=firm):return git('rev-parse',rev+':'+p).decode().strip()
def save(n,x):(d/n).write_text(json.dumps(x,indent=2)+'\n')
def h(x):return sha256(x).hexdigest()
pins={
'build9 IPA':'dde4992f24f52d4390391069025b27092a2f327e3a53115bdd53a6ede0dffa8e',
'AU archive':'abe2f2e089306770489fb30c8870f608dc2f2e0804541f624337523679638a28',
'AU executable':'a5243e50bda6bd44f463c6e63ea3137802142f55f3c1ea25a5a6e046acba81a1',
'standalone app':'931976820fc5f967a979661aac52e508277e9164fdc33e6b68b1573b69cf290a',
'factory ZIP':'ab702e00b4cc425c9406b9b2b44e68ba0f40e1125d591fcaa422cc6a8c6272b8',
'bounded bench':'c1b7e99bf4f3054f114557a66c5ad8060525a5f8065e3ff3c7d208dbe2d9bf9c',
'active matrix':'08b912309b24edceebb159b8e3b1be1b3befc706201602212885ad73dd6cd3e0',
'later decision ZIP':'8f99329155a1b075b81319937bd0187a7d196c65f8bf6eda1cc9ea8c7ab97c6f',
'later decision markdown':'e1a4cac2a8f0fddd2ab62608d08d3e6df26be0023cbe78ff2688de2a6b53e7c6',
'later picks PNG':'d219ab459a456553399fca5d7d65b1f713c4ec0766240c35bddf0b4b6a07bd6b',
'R22 source map archive':'9bdc25287049626bb7daa45c5d2dbd071a790f4361be1922156c0f0e28b54c91',
'later R22 approved MIX owner PNG':'a22f56bd5404ccc3f0b29adc2c4c7e022e103985a04c3a154fd3d4891717dea7',
'R22 approved MIX archive':'fe054e752b3c2790bc30b037d1945e3f5f98146654121cfa013eb4d605d229f2'}
linux='experiments/sound-hardware-v1/sj6-factory/original/'
scenes=json.loads(obj(linux+'component-replay.json'))['scenes']
pins.update({'recorded component / '+k:v for k,v in scenes.items()})
dated_mentions=set(); formatter_candidates=set(); named_members=set()
exact_names={'safe_arm64.py','original_chorus_audio.py','original_synth_smoke.py','original_sampler_smoke.py','macho_dsp.py','sampler_dsp.py','static_routes.py','GLYPH-DECISIONS.md','GLYPH-PICKS.png','J6presets.zip'}
matches=defaultdict(list); pinhash={v:k for k,v in pins.items()}
refs={}; checks=Counter(); archive_rows=[]; limited=[]; paths_by_oid=defaultdict(list); byp={}
def accept(path,b):
 if (b'17:00' in b or b'GLYPH-DECISIONS' in b or b'GLYPH-PICKS' in b) and b'\x00' not in b[:256]:
  if re.search(rb'(17:00.{0,100}glyph|glyph.{0,100}17:00|17:00[- ]batch|GLYPH-DECISIONS|GLYPH-PICKS)',b,re.I):dated_mentions.add(path)
 if b'neonlfo1Rate' in b and b'division' in b.lower() and b'\x00' not in b[:256]:formatter_candidates.add(path)
 if path.replace('!','/').split('/')[-1] in exact_names:named_members.add(path)
 k=pinhash.get(h(b))
 if k:matches[k].append(path)
def archive(path,b,level=0):
 if level>5:limited.append([path,'depth']);return
 if b.startswith(b'PK\x03\x04'):
  with zipfile.ZipFile(BytesIO(b)) as f:
   names=[(entry.filename,entry.file_size) for entry in f.infolist() if not entry.is_dir()]
   archive_rows.append([path,len(names),sum(s for _,s in names)])
   for name,size in names:
    if size>64<<20:limited.append([path+'!'+name,'member size']);continue
    data=f.read(name);members(path,name,data,level)
  return
 ext=None
 if b.startswith(b'\x1f\x8b'):ext=gzip.GzipFile
 elif b.startswith(b'\xfd7zXZ\x00'):ext=lzma.LZMAFile
 if ext:
  f=ext(fileobj=BytesIO(b)) if ext==gzip.GzipFile else ext(BytesIO(b))
  with f: plain=f.read((96<<20)+1)
  if len(plain)>96<<20:limited.append([path,'expanded size']);return
  checks['decoded_streams']+=1;accept(path+'!uncompressed',plain)
 else:plain=b
 if plain[257:262]==b'ustar':
  with tarfile.open(fileobj=BytesIO(plain),mode='r:') as tf:
   items=[m for m in tf.getmembers() if m.isfile()]
   archive_rows.append([path,len(items),sum(m.size for m in items)])
   for m in items:
    if m.size>64<<20:limited.append([path+'!'+m.name,'member size']);continue
    data=tf.extractfile(m).read();members(path,m.name,data,level)
 elif ext and plain.startswith((b'PK\x03\x04',b'\x1f\x8b',b'\xfd7zXZ\x00')):archive(path+'!decoded',plain,level+1)
def members(path,name,b,level):
 checks['archive_members_hashed']+=1;checks['archive_member_bytes_hashed']+=len(b)
 ref=path+'!'+name;accept(ref,b);archive(ref,b,level+1)
index=git('ls-tree','-rl',firm).decode().splitlines()
for line in index:
 meta,path=line.split('\t',1); mode,kind,key,size=meta.split()
 if kind!='blob':continue
 paths_by_oid[key].append(path);byp[path]=key
checks['tracked_blob_paths']=len(byp);checks['distinct_blobs']=len(paths_by_oid)
proc=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
signature=Counter(); multipart=[]
for key,paths in paths_by_oid.items():
 proc.stdin.write((key+'\n').encode());proc.stdin.flush()
 hdr=proc.stdout.readline().split();size=int(hdr[2]);b=proc.stdout.read(size);assert proc.stdout.read(1)==b'\n'
 checks['bytes_hashed_from_distinct_git_blobs']+=size
 for path in paths:accept(path,b)
 p=paths[0]
 if p.endswith(('.part00','.part01')):multipart.append((p,b))
 else:archive(p,b)
proc.stdin.close();assert proc.wait()==0
combined=b''.join(v for _,v in sorted(multipart))
accept('joined Synth One test input',combined);archive('joined Synth One test input',combined)
for file in ['lfo_laws.cpp','lfo_laws.hpp','conductor.hpp','test_lfo_laws.cpp']:
 p='experiments/superj6-conductor-source-20261115/'+file
 key=oid(p,conductor)
 refs[file]={'donorBlob':key,'exactContentPathsInConsolidated':paths_by_oid.get(key,[])}
children=git('ls-tree','-r','--name-only',firm,'--',linux).decode().splitlines()
donor_rows=[{'file':p[len(linux):],'historical973Blob':oid(p,prior),'live973Blob':oid(p,donor),'consolidatedBlob':byp[p]} for p in children]
screen='docs/lanes/fwui/screens/'
indexbuf=obj(screen+'screen-index.tsv')
catalog=json.loads(obj(screen+'index.json'))['currentCatalog']
assert h(indexbuf)==catalog['indexSHA256']
rows=list(csv.DictReader(indexbuf.decode().splitlines(),delimiter='\t'))
assert len(rows)==catalog['frames']
jrows=[row for row in rows if row['state_id'].startswith('superj6/')]
frames='docs/lanes/fwui/current/superj6-slot/'
man=json.loads(obj(frames+'frames.json'));frames_data=obj(frames+man['archive'])
assert h(frames_data)==man['archive_sha256']
lfo=[];verified=0
with tarfile.open(fileobj=BytesIO(frames_data)) as tf:
 for f in man['frames']:
  payload=tf.extractfile(f['file']).read();assert h(payload)==f['sha256']
  with Image.open(BytesIO(payload)) as im:
   assert im.size==(240,240) and h(im.convert('RGB').tobytes())==f['rgb_sha256']
  row=next(x for x in jrows if x['png_path']==f['file']);assert row['rgb_sha256']==f['rgb_sha256']
  verified+=1
  if 'lfo' in f['file']:lfo.append(row)
save('inventory.json',{'firmware':firm,'tree':git('rev-parse',firm+'^{tree}').decode().strip(),'publicSoundPR973':donor,'publishedLinuxBenchDonor':prior,'originalDerivedConductorDonor':conductor,'limits':{'maxDecompressedStreamMiB':96,'maxArchiveMemberMiB':64,'maxDepth':5,'limited':limited},'coverage':dict(checks),'exactPins':{k:{'sha256':v,'found':matches[k]} for k,v in pins.items()},'joinedParts':[p for p,_ in sorted(multipart)],'linuxDonorFiles':donor_rows,'numericSourceDonor':refs,'catalog':{**catalog,'indexedJ6Frames':len(jrows),'stockCompactRGBsIndependentlyVerified':verified,'provider':man['provider'],'stockLFOAndChorusFrames':lfo},'catalogViewportReport':json.loads(obj('docs/lanes/fwui/current/panel-routes/catalog-viewport-199f0444.json')),'stockOriginalLinuxReceipt':json.loads(obj(linux+'component-replay.json')),'stockOriginalInitReceipt':json.loads(obj(linux+'instrument-init.json'))})
save('archive-members-summary.json',archive_rows)
brief='experiments/sound-hardware-v1/mapping/results/implementer_brief/'
baseline='468744971720a81a536308e3bd84bd8766a5ed0f'
graphics=['docs/design/UI-SOURCE-OF-TRUTH.md','docs/design/OWNER-BASELINE-1836-NOTES.md','docs/design/OWNER-BASELINE-1836.pdf','reference/recovered-ui/mocks/glyphs']
public=json.loads(obj(brief+'public_control_catalog.json'))
save('targeted-source.json',{'namesInTrackedOrArchivedContent':sorted(named_members),'datedGlyphMentions':sorted(dated_mentions),'fieldSpecificIdentifierAndDivisionText':sorted(formatter_candidates),'originalFactoryValuesAudited':json.loads(obj(linux+'all-programs.json'))['totals'],'comparableSource':{p:{'base':oid(p,baseline),'consolidated':oid(p)} for p in graphics},'linuxSubtree':{s:oid(linux.rstrip('/'),s) for s in [firm,prior,donor]},'bindingControls':[c for c in public['controls'] if c['id'] in [88,96,100,195,196,197]],'numericSource':{p:{'03f92a7d':oid(p,'03f92a7d94ad29bdb4a6bb238311ba12776401ea'),'f1786ebe':oid(p)} for p in [brief+'BEHAVIOR-BRIEF.md',brief+'public_control_catalog.json',brief+'numeric_behavior_targets.json']},'compactFirmwareReview':json.loads(obj('docs/lanes/fwui/current/panel-routes/independent-review.json'))['geometry']})

