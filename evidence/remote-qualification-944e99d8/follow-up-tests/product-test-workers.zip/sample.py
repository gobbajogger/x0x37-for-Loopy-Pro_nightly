from pathlib import Path
import json,os,signal,subprocess,sys,time
mode=sys.argv[1]
work=Path(__file__).parent.resolve()
repo=work/'repo';out=repo/'.output';out.mkdir(exist_ok=True)
sc=(work/(mode+'-tmp'));sc.mkdir(exist_ok=True)
cmd=['npm','run','test:product']
if mode=='default':
 args=json.loads((repo/'package.json').read_text())['scripts']['test:product'].split(' && ')[0].split()
 cmd=[s for s in args if s!='--test-concurrency=1']
env={**os.environ,'TMPDIR':str(sc)}
seen=set(); maxdirs=peakbytes=peakdisk=0; atmax=[];peakContents={};beg=time.monotonic();stat=os.statvfs(repo);startFree=stat.f_bavail*stat.f_frsize;minfree=startFree
samples=0;reason=None
with (work/(mode+'.log')).open('wb') as log:
 p=subprocess.Popen(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 while p.poll() is None:
  stat=os.statvfs(repo);free=stat.f_bavail*stat.f_frsize;minfree=min(minfree,free);nbytes=nalloc=0;dirs=[]
  for child in out.iterdir():
   if not child.is_dir() or not child.name.startswith(('emu-env-','http-','content-test-')):continue
   sizes=[]
   try:
    for d,_,files in os.walk(child):
     for f in files:
      try:
       s=os.stat(os.path.join(d,f));sizes.append((s.st_size,s.st_blocks*512))
      except FileNotFoundError:pass
   except FileNotFoundError:pass
   dirs.append(child.name);seen.add(child.name);nbytes+=sum(s[0] for s in sizes);nalloc+=sum(s[1] for s in sizes)
  if len(dirs)>maxdirs:maxdirs=len(dirs);atmax=sorted(dirs)
  if nbytes>peakbytes:peakbytes=nbytes;peakContents={'elapsed_s':round(time.monotonic()-beg,3),'dirs':sorted(dirs)}
  peakdisk=max(peakdisk,nalloc);samples+=1
  if mode=='default' and free<48*1024**2:
   reason='stopped diagnostic baseline at filesystem reserve';os.killpg(p.pid,signal.SIGTERM);break
  time.sleep(.025)
 code=p.wait()
obj={'command':cmd,'exit':code,'earlyStop':reason,'elapsed_s':round(time.monotonic()-beg,3),'samples':samples,'uniqueFullSiteFixtureDirectoriesObserved':len(seen),'maximumConcurrentFullSiteFixtureDirectoriesObserved':maxdirs,'firstMaximumDirectorySample':atmax,'maximumCumulativeFixtureFileBytesObserved':peakbytes,'maximumCumulativeAllocatedFileBytesObserved':peakdisk,'maximumByteSample':peakContents,'startFilesystemAvailable':startFree,'minimumFilesystemAvailableObserved':minfree}
(work/(mode+'.json')).write_text(json.dumps(obj,indent=2)+'\n')
print(json.dumps(obj))
