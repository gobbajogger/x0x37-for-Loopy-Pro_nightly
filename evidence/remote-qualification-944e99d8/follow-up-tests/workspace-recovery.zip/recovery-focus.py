import asyncio, importlib.util, json, time
from pathlib import Path
from playwright.async_api import async_playwright

work = Path(__file__).resolve().parent
root = work.parent / 'nightly'
spec = importlib.util.spec_from_file_location('core', root / 'tests/product-remote/envelope-browser.py')
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)

async def measure(origin):
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(chromium_sandbox=True)
        try:
            page = await browser.new_page(viewport={'width':1440,'height':900})
            started = time.monotonic()
            events = []
            def record(label):
                events.append({'event': label, 'seconds':round(time.monotonic()-started,3)})
            page.on('pageerror',lambda err:record('page error '+str(err)))
            async def refuse(route):
                await route.fulfill(status=503, content_type='application/json',body='invalid')
                record('trace.json fulfilled with HTTP 503')
            await page.route('**/remote/trace.json',refuse)
            await page.goto(origin+'/remote/')
            record('goto returned')
            alert = page.locator('#workspace-error')
            await alert.wait_for(state='visible',timeout=45000)
            record('error alert visible')
            assert await page.locator('#workspace-retry').evaluate('e => e === document.activeElement')
            assert await page.locator('[data-view="sound"]').is_disabled()
            await page.unroute('**/remote/trace.json',refuse)
            await page.locator('#workspace-retry').click(timeout=20000)
            await page.wait_for_function("document.querySelector('main').getAttribute('aria-busy') === 'false'", timeout=45000)
            assert await page.locator('[data-view="sound"]').is_enabled()
            assert not await alert.is_visible()
            record('Retry reloaded workspace and enabled Sound')
            assert sum('HTTP 503' in x['event'] for x in events) == 1
            assert not any(x['event'].startswith('page error') for x in events)
        finally:
            print(json.dumps(events),flush=True)
            await browser.close()

with core.server(root / '.output/product-site') as origin:
    asyncio.run(measure(origin))
