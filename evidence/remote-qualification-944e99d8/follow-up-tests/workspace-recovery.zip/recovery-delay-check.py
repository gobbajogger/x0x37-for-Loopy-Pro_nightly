"""Inject a post-navigation network delay into the real first recovery test case."""
import asyncio
import json
import subprocess
import sys
from pathlib import Path

work = Path(__file__).resolve().parent
root = work.parent / 'nightly'
relative = Path('tests/product-workspace/recovery-browser.py')
mode = sys.argv[1]
if mode == 'original':
    source = subprocess.check_output(['git','-C',str(root),'show','944e99d:'+str(relative)]).decode()
else:
    source = (work/'recovery-patch'/relative).read_text()
start = source.index('      wave=page.locator(')
end = source.index('     finally:await context.close()',start)
source = source[:start]+"      print('PASS delayed 503: alert, focused Retry, disabled Sound and successful workspace recovery',flush=True)\n      return\n"+source[end:]
# Bound the delay to the interval after the test has navigated, independently of host load.
source = source.replace("source='catalog' if bad=='malformed' else bad", "source='catalog' if bad=='malformed' else bad\n      navigated=asyncio.Event()")
source = source.replace('async def refuse(route):await route.fulfill(', 'async def refuse(route):\n       await navigated.wait()\n       await asyncio.sleep(6.2)\n       if page.is_closed():return\n       await route.fulfill(')
source = source.replace("await page.goto(origin+'/remote/')", "await page.goto(origin+'/remote/');navigated.set()")
namespace={'__file__':str(root/relative), '__name__':'recovery_delay_fixture'}
exec(compile(source,str(root/relative), 'exec'),namespace)
with namespace['core'].server(root/'.output/product-site') as origin:
    asyncio.run(namespace['cases'](origin))
