"""Hold one successful input during the real Retry; compare the readiness checks."""
import asyncio
import subprocess
import sys
from pathlib import Path
work=Path(__file__).resolve().parent
root=work.parent/'qual-next'
relative=Path('tests/product-workspace/recovery-browser.py')
mode=sys.argv[1]
source=(root/relative).read_text() if mode=='original' else (work/'recovery-patch'/relative).read_text()
start=source.index('      wave=page.locator(')
end=source.index('     finally:await context.close()',start)
source=source[:start]+"      print('PASS Retry after 6.2s delayed source, enabled Sound and hidden alert',flush=True)\n      return\n"+source[end:]
marker="await page.unroute('**/remote/'+source+'.json',refuse)"
source=source.replace(marker,"""async def hold_source(route):
       await asyncio.sleep(6.2)
       if not page.is_closed():await route.continue_()
      """+marker+"\n      await page.route('**/remote/source-sounds.json',hold_source)")
ns={'__file__':str(root/relative),'__name__':'bounded_retry'}
exec(compile(source,str(root/relative),'exec'),ns)
with ns['core'].server(work.parent/'nightly/.output/product-site') as origin:
    asyncio.run(ns['cases'](origin))
