# Builds screenshot at 1440 × 900

The ordinary visual gate on `4421b615811a50cb844ec0733bdd1bd605e398ba` reached the Builds history page and exhausted the 30-second capture budget. The final failing browser call had 638 ms left after earlier work. Its call log confirms the fonts were loaded. The gate first settles navigation, styles, font loading and network idle. It then starts the capture clock. Its three native clips cover the 1440 × 72,520 document, with a single overlap row at each seam. The desktop page appears once in the route list. The existing 18-contract-test suite passed, including the test that rejects a complete late image.

These focused runs served the existing product build. The seven relevant served files matched both the gate’s source files and the historical native reference by SHA-256. All runs used Playwright 1.62.0, bundled sandboxed Chromium 151.0.7922.34, the gate’s browser options and fixed clock, the original DPR 1 and 198 history entries, and the original lossless band assembly.

| Run | Native band times in seconds | Total capture time | Result |
|---|---|---:|---|
| Ordinary Playwright, first replay | 19.568, second timed out after 10.461 | 43.957 s | Failed inside the 10,383 ms remaining browser operation. The helper then waited for its pending worker to exit. |
| Ordinary Playwright, second replay | 12.890, 8.839, 6.926 | 30.442 s | All three clips returned. The final assembled-image deadline rejected the result. |
| CDP PNG speed experiment | 10.567, 5.828, 4.180 | 21.769 s | The complete PNG matched the archived native RGB and final row. Its compressed bytes also matched the prior banded PNG. |

The first full-gate failure and both focused ordinary failures remain recorded. Host scheduling differed across runs, so the timings quantify these observations only. The historical same-input reference completed band capture in 14.976 s.

## Pixel comparison

The diagnostic used public Chromium `Page.captureScreenshot` with PNG, the same document clip, scale 1, capture beyond the viewport, from-surface rendering and `optimizeForSpeed: true`. It preserved the standard seam and geometry checks and the final 30-second check. Its independent reader validated every PNG chunk CRC, all 72,520 complete scanlines and the final row, then compared the full RGB hash with the archived stock native screenshot. The output contained 104,428,800 pixels and 313,286,400 RGB bytes. It compared exactly, including the final 1,440-pixel row.

| Comparison | SHA-256 |
|---|---|
| All decoded RGB | `bfe8b6d652f0ca42001fa5e733a4e18e4b8b69ad110d29fc24a55c287123c40a` |
| Final RGB row | `3134f98ce8761cc128cbcf7d19aa34135c646ee64e49ffd1a514369201910b02` |
| Assembled 9,435,853-byte PNG | `051cd49a975e370c271cfc03fa2df89d4b74eeee40c60557a1dfa92b1152e913` |

The synchronous Playwright screenshot API supports an in-flight timeout but does not expose this PNG compression flag. Its public synchronous `CDPSession.send(method, params)` has no timeout argument. The timing experiment checks elapsed time when each CDP command returns and has an outer process watchdog. Those checks do not cancel an individual stalled CDP command on the original remaining budget. The measured diagnostic therefore leaves the ordinary gate failure open. No repository code was changed.

## Reproduction

Use the existing built checkout and normal pinned browser qualification environment. Set `EVIDENCE` to this extracted directory, `CHECKOUT` to the exact checkout and `REV` to its full commit. The driver writes JSON only and retains every image in memory. A failed capture returns a nonzero exit code and writes the timing and error first. The direct CDP experiment uses an outer watchdog as an additional bound on the diagnostic process.

```sh
python "$CHECKOUT/tests/visual/test_visual_gate.py"
python "$EVIDENCE/replay.py" "$CHECKOUT" "$REV" fresh-ordinary.json
timeout --kill-after=4s 90s python "$EVIDENCE/replay.py" "$CHECKOUT" "$REV" fresh-fast.json --cdp-fast
```

`full-gate-extract.log` preserves the initial failure. `replay.json` and `replay-second.json` retain the ordinary timings, call arguments and exceptions. `cdp-fast.json` contains the completed diagnostic and hashes. `identity.json` records the source identities and pinned public API signature. The `source` directory contains the exact capture helper, gate entry point, contract tests and archived native reference receipt.
