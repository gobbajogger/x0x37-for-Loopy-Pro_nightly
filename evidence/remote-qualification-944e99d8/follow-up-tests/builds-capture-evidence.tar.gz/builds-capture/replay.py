"""Time existing calls in the normal Builds visual capture, without changing their inputs or budget."""
from contextlib import closing
import base64
import hashlib
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from importlib.metadata import version
import functools
import json
from pathlib import Path
import struct
import sys
import threading
import time
import zlib

from playwright.sync_api import sync_playwright

here=Path(__file__).resolve().parent
checkout=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(checkout/'tests/visual'))
import visual_gate as gate
import full_page_capture as capture

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self,*args): pass

def inspect_png(data):
    i=8
    decoder=zlib.decompressobj()
    stash=bytearray()
    digest=hashlib.sha256()
    count=0
    assert data[:8]==b'\x89PNG\r\n\x1a\n'
    while i<len(data):
        n,=struct.unpack('>I',data[i:i+4])
        kind=data[i+4:i+8];body=data[i+8:i+8+n]
        crc,=struct.unpack('>I',data[i+8+n:i+12+n])
        assert zlib.crc32(kind+body)&0xffffffff==crc
        if kind==b'IHDR':
            width,height,depth,colour,compression,flt,interlaced=struct.unpack('>IIBBBBB',body)
            assert (depth,colour,compression,flt,interlaced)==(8,2,0,0,0)
            row=width*3+1
        if kind==b'IDAT':
            for start in range(0,len(body),4096):
                stash.extend(decoder.decompress(body[start:start+4096]))
                past=len(stash)//row*row
                if past:
                    batch=memoryview(stash)
                    for offset in range(0,past,row):
                        assert batch[offset]==0
                        rgb=batch[offset+1:offset+row]
                        digest.update(rgb);last=hashlib.sha256(rgb).hexdigest()
                        count+=1
                    del rgb,batch
                    del stash[:past]
        i+=12+n
    assert kind==b'IEND' and not stash and count==height and decoder.eof and not decoder.unused_data
    return dict(width=width,height=height,rows=count,rgb=digest.hexdigest(),finalRow=last,png=hashlib.sha256(data).hexdigest(),pngBytes=len(data))

receipt={'browserTool':version('playwright'),'sha':sys.argv[2],'bands':[]}
out=here/(sys.argv[3] if len(sys.argv)>3 else 'replay.json')
cdp_fast='--cdp-fast' in sys.argv
receipt['method']='Page.captureScreenshot optimizeForSpeed' if cdp_fast else 'Page.screenshot'

archived=json.loads((checkout/'evidence/web-routes/builds-full-page-capture.json').read_text())
article=archived['viewports'][0]
for path,expected in archived['source_sha256'].items():
    built=checkout/'.output/product-site'/Path(path).relative_to('web/product-site')
    assert hashlib.sha256(built.read_bytes()).hexdigest()==expected
class Timed:
    def __init__(self,page):
        self.page=page
        self.cdp=page.context.new_cdp_session(page) if cdp_fast else None
    def evaluate(self,*a,**kw):return self.page.evaluate(*a,**kw)
    def screenshot(self,**kw):
        record=dict(arguments=kw);receipt['bands'].append(record)
        start=time.monotonic()
        try:
            if self.cdp is None:
                band=self.page.screenshot(**kw)
            else:
                # A timing experiment only. CDPSession.send has no public timeout argument.
                assert kw['full_page'] and self.page.viewport_size=={'width':1440,'height':900}
                data=self.cdp.send('Page.captureScreenshot',{'format':'png','clip':dict(kw['clip'],scale=1),'fromSurface':True,'captureBeyondViewport':True,'optimizeForSpeed':True})
                band=base64.b64decode(data['data'])
                if time.monotonic()-start > kw['timeout']/1000:
                    raise TimeoutError('Native tile exceeded remaining Builds budget')
            record['bytes']=len(band)
            return band
        finally:
            record['seconds']=round(time.monotonic()-start,3)
            out.write_text(json.dumps(receipt,indent=2)+'\n')
try:
    with ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(checkout/'.output'))) as server:
        threading.Thread(target=server.serve_forever,daemon=True).start()
        with sync_playwright() as pw, closing(gate.viewport_contexts(pw)) as contexts:
            w,h,context=next(contexts)
            receipt['browser']=context.browser.version
            receipt['viewport']=[w,h]
            page=context.new_page();errors=[]
            page.on('pageerror',lambda err:errors.append(str(err)))
            page.goto(f'http://127.0.0.1:{server.server_port}/product-site/builds/index.html')
            page.add_style_tag(content=gate.FREEZE_CSS)
            page.evaluate('document.fonts.ready');page.wait_for_load_state('networkidle')
            page.wait_for_timeout(250)
            receipt['geometry']=page.evaluate(capture.GEOMETRY)
            receipt['entries']=page.locator('.build-record').count()
            receipt['fonts']=page.evaluate('document.fonts.status')
            started=time.monotonic()
            try: result=gate.capture_full_page(Timed(page),'builds/index.html','site-builds-1440x900')
            finally: receipt['seconds']=round(time.monotonic()-started,3)
            receipt['pixels']=inspect_png(result)
            receipt['archivedNativeRGBMatch']=receipt['pixels']['rgb']==article['native_rgb_sha256']
            receipt['archivedFinalRowMatch']=receipt['pixels']['finalRow']==article['final_row_rgb_sha256']
            receipt['archivedBandedPNGMatch']=receipt['pixels']['png']==article['candidate_png_sha256']
            receipt['errors']=errors
            assert not errors and receipt['entries']==archived['records'] and receipt['archivedNativeRGBMatch'] and receipt['archivedFinalRowMatch']
            receipt['result']='PASS'
except Exception as error:
    receipt['result']='FAIL'
    receipt['error']=str(error)
    raise
finally:
    out.write_text(json.dumps(receipt,indent=2)+'\n')
