import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const checkout=pathToFileURL(resolve(process.argv[2])+'/');
const {createKernelWasi,assertKernelImports}=await import(new URL('.output/product-site/emu/wasi.mjs',checkout));
const holdMs=Number(process.argv[3]??80), gapMs=Number(process.argv[4]??0);
const here = new URL('./',import.meta.url);
const pin=JSON.parse(fs.readFileSync(new URL('tests/fixtures/emulator-lcd-61827a/frames.json',checkout)));
const bytes=fs.readFileSync(new URL('.output/product-site/emu/kernel.wasm',checkout));
function digest(b){return createHash('sha256').update(b).digest('hex')}
if(digest(bytes)!==pin.wasm_sha256)throw Error('WASM identity differs');
const mod=await WebAssembly.compile(bytes);
let ex,clock=0;const wasi=createKernelWasi(()=>ex.memory,{clockNanoseconds:()=>BigInt(Math.round(clock/44100*1e9))});
assertKernelImports(mod,wasi);({exports:ex}=await WebAssembly.instantiate(mod,{wasi_snapshot_preview1:wasi}));ex._initialize?.();if(ex.web_boot()!==0)throw Error('boot');
let lastBlit=-1,active=null;
const changes=[],visited=new Set();
function frame(){return Buffer.from(new Uint16Array(ex.memory.buffer,ex.web_framebuffer(),240*240).slice().buffer)}
function compare(label,pngName){
 const fb=frame();const native=fs.readFileSync(new URL(pngName+'.rgb565',here));
 if(digest(native)!==pin.frames[pngName])throw Error('Native input differs: '+pngName);
 let n=0;let bx=240,by=240,rx=0,ry=0;
 for(let i=0;i<fb.length;i+=2)if(fb.readUInt16BE(i)!==native.readUInt16BE(i)){n++;const j=i/2;bx=Math.min(bx,j%240);by=Math.min(by,Math.floor(j/240));rx=Math.max(rx,j%240);ry=Math.max(ry,Math.floor(j/240));}
 const sha=digest(fb);const k=label+n+'-'+sha;
 if(!visited.has(k)){visited.add(k);changes.push({step:label,at:ex.web_time(),n,box:n?[bx,by,rx+1,ry+1]:null,sha});}

}
function run(ms){let end=ex.web_time()+ms;while(ex.web_time()<end){let rc=ex.web_render(128);if(rc!==0)throw Error('render '+rc);clock+=128;let blit=ex.web_blits();if(active && blit!==lastBlit){compare(active,active);lastBlit=blit;}}}
function hold(bit,ms=40){ex.web_buttons(1<<bit);run(ms);ex.web_buttons(0);run(40)}
run(523);compare('boot','boot');
run(35);hold(0,78);run(440);run(35);hold(7,78);run(197);run(69);hold(6,78);run(2949);
hold(3);run(1700);ex.web_turn(3,1);run(1700);hold(4);run(1700);ex.web_turn(1,1);run(1700);hold(9);run(1700);
compare('seq-808','seq-808'); if(gapMs)run(gapMs); active='global';hold(5,holdMs);run(2300);active='midi-clock';hold(1);run(2300);
fs.writeFileSync(new URL('native-route-'+holdMs+'-gap'+gapMs+'.json',here),JSON.stringify(changes,null,2)+'\n');console.log(changes);
