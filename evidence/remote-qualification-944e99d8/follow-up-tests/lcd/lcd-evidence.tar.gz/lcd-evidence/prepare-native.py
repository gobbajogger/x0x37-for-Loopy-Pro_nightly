"""Prepare manifest-checked native pixel input for the WASM-only replay."""
import hashlib, json, sys
from pathlib import Path
from PIL import Image
here = Path(__file__).resolve().parent
fixtures = Path(sys.argv[1]).resolve() / 'tests/fixtures/emulator-lcd-61827a'
expected = json.loads((fixtures/'frames.json').read_text())['frames']
red_blue = {i*255//31: i for i in range(32)}
green = {i*255//63: i for i in range(64)}
for name in ('boot','seq-808','global','midi-clock'):
    image = Image.open(fixtures/(name+'.png')).convert('RGB')
    assert image.size == (240,240)
    data = b''.join(((red_blue[r]<<11)|(green[g]<<5)|red_blue[b]).to_bytes(2,'big') for r,g,b in image.getdata())
    assert hashlib.sha256(data).hexdigest()==expected[name]
    (here/(name+'.rgb565')).write_bytes(data)
