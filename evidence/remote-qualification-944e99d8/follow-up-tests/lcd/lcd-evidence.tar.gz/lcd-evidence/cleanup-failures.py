from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer
from threading import Thread
from unittest.mock import patch
import importlib.util, sys, json, io
from PIL import Image
from playwright.sync_api import sync_playwright, TimeoutError
from cleanup_probe import OBSERVER, assert_cleanup

here = Path(__file__).resolve().parent
checkout = Path(sys.argv[1]).resolve()
spec = importlib.util.spec_from_file_location('lcd', here/'candidate/tests/emulator-lcd-browser.py')
lcd = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lcd)
lcd.ROOT = here/'cleanup-failures'
lcd.ROOT.mkdir(exist_ok=True)
site = checkout/'.output/product-site'
fixtures = checkout/'tests/fixtures/emulator-lcd-61827a'
manifest = json.loads((fixtures/'frames.json').read_text())
normal = lcd.check_frame
def corrupt(name, fixtures, manifest, stamp, data):
    image = Image.open(io.BytesIO(data)).convert('RGBA')
    r,g,b,a = image.getpixel((0,0))
    levels = [round(i*255/31) for i in range(32)]
    image.putpixel((0,0),(levels[levels.index(r)^1],g,b,a))
    stream = io.BytesIO()
    image.save(stream,'PNG')
    normal(name,fixtures,manifest,stamp,stream.getvalue())

record = {}
with ThreadingHTTPServer(('127.0.0.1',0),partial(lcd.QuietHandler,directory=str(site))) as server:
    thread=Thread(target=server.serve_forever,daemon=True)
    thread.start()
    try:
        with sync_playwright() as pw, pw.chromium.launch(chromium_sandbox=True) as browser:
            record['browser'] = browser.version
            url = f'http://127.0.0.1:{server.server_port}'
            with browser.new_page() as page:
                page.add_init_script('('+OBSERVER+')()')
                with patch.object(lcd,'check_frame',corrupt):
                    try: lcd.check_page(page,url+'/emu/',manifest,fixtures)
                    except AssertionError as exc:
                        assert str(exc).startswith('boot: 1/57600 RGB565 pixels differ'), str(exc)
                        record['singlePixelError'] = str(exc)
                    else: raise AssertionError('corruption accepted')
                record['afterMismatch'] = assert_cleanup(page,running=True)
            with browser.new_page() as page:
                # Exercise the inherited-method path as well, preserving the real AudioContext.
                page.add_init_script('window.AudioContext = class extends window.AudioContext {}; ('+OBSERVER+')()')
                page.route('**/welcome-without-start',lambda route: route.fulfill(content_type='text/html',body='<h1>Welcome</h1>'))
                page.set_default_timeout(700)
                try: lcd.check_page(page,url+'/welcome-without-start',manifest,fixtures)
                except TimeoutError as exc:
                    assert "#start" in str(exc)
                    record['missingStartError'] = str(exc)
                else: raise AssertionError('missing Start accepted')
                record['beforeStart'] = assert_cleanup(page,running=False)
            with browser.new_page() as page:
                page.goto(url+'/emu/')
                try:
                    with lcd.capture_lcd_clock(page):
                        page.close()
                        raise RuntimeError('primary failure')
                except RuntimeError as exc:
                    assert str(exc)=='primary failure'
                    record['preservedErrorIfCleanupFails']=str(exc)
                else: raise AssertionError('primary failure lost')
    finally:
        server.shutdown()
        thread.join()
print(json.dumps(record,indent=2))
(lcd.ROOT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
