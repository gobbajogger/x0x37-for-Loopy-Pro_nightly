from pathlib import Path
import importlib.util,io,json,sys
from PIL import Image
here=Path(__file__).resolve().parent
f=here/'candidate/tests/emulator-lcd-browser.py';sp=importlib.util.spec_from_file_location('lcd',f);app=importlib.util.module_from_spec(sp);sp.loader.exec_module(app)
run=here/'one-pixel';run.mkdir(exist_ok=True);app.ROOT=run
fixtures=Path(sys.argv[1]).resolve()/'tests/fixtures/emulator-lcd-61827a';manifest=json.loads((fixtures/'frames.json').read_text())
actual=(here/'second/global-actual.png').read_bytes(); app.check_frame('global',fixtures,manifest,0,actual)
img=Image.open(io.BytesIO(actual)).convert('RGBA');r,g,b,a=img.getpixel((0,0))
levels=[round(i*255/31) for i in range(32)];img.putpixel((0,0),(levels[levels.index(r)^1],g,b,a))
buf=io.BytesIO();img.save(buf,'PNG')
try:app.check_frame('global',fixtures,manifest,0,buf.getvalue())
except AssertionError as e:
 assert 'global: 1/57600' in str(e),e
 frame=json.loads(next((run/'.output').glob('lcd-global-mismatch-*/frame.json')).read_text())
 assert frame['bounds']==[0,0,1,1] and frame['changed_pixels']==1,frame
 (run/'control.json').write_text(json.dumps({'initialExact':True,'changedOneRepresentableBit':True,'rejected':True,'frame':frame},indent=2)+'\n')
 print(str(e))
else:raise AssertionError('Corruption was accepted')
