from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer
from threading import Thread
import importlib.util,sys,json,time
from playwright.sync_api import sync_playwright
from cleanup_probe import OBSERVER, assert_cleanup
here=Path(__file__).resolve().parent
root=Path(sys.argv[1]).resolve();mode=sys.argv[2]
run=here/('controlled-'+mode);run.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('lcd',here/'candidate/tests/emulator-lcd-browser.py')
app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app);app.ROOT=run
site=root/'.output/product-site';fixtures=root/'tests/fixtures/emulator-lcd-61827a';manifest=json.loads((fixtures/'frames.json').read_text())
orig_press=app.press_lcd_control; orig_advance=app.advance_lcd
last=None;rows=[];record={}
def press(page,name):
 global last
 last=name
 if name=='GLOBE':
  before=page.evaluate("Number(document.querySelector('#lcd').dataset.time)")
  if mode=='red-replay':
   # Stage a measured action-delivery delay, then hold the clock during
   # pointer positioning so outer runner jitter cannot erase the toast.
   orig_advance(page,2360)
   orig_press(page,name)
   orig_advance(page,110)
   record['originalBefore']=before
   return
  if mode=='red':
   page.evaluate('window.lcdTestClock.audio.resume()')
   page.wait_for_function("start => Number(document.querySelector('#lcd').dataset.time) > start+2360",arg=before)
   page.get_by_role('button',name=name,exact=True).click(delay=80)
   # Keep the original gate's wait anchored before Playwright action delivery.
   record['originalBefore']=before
   return
  elif mode=='green':
   time.sleep(3)
   record['simulatedDuringUserDelay']=page.evaluate("Number(document.querySelector('#lcd').dataset.time)")-before
 orig_press(page,name)
def advance(page,delta):
 if last=='GLOBE' and mode.startswith('red') and delta==1700:
  page.wait_for_function("t=>Number(document.querySelector('#lcd').dataset.time)>t",arg=record['originalBefore']+delta)
 else:orig_advance(page,delta)
 rows.append([last,delta,page.evaluate("Number(document.querySelector('#lcd').dataset.time)")])
app.press_lcd_control=press;app.advance_lcd=advance
original_check=app.check_frame
def check_frame(name,fixtures,manifest,stamp,actual_png):
 if name in ['global','midi-clock']:
  (run/(fixtures.name+'-'+name+'-actual.png')).write_bytes(actual_png)
 record.setdefault('observed',[]).append([fixtures.name,name,stamp])
 original_check(name,fixtures,manifest,stamp,actual_png)
app.check_frame=check_frame
with ThreadingHTTPServer(('127.0.0.1',0),partial(app.QuietHandler,directory=str(site))) as srv:
 t=Thread(target=srv.serve_forever,daemon=True);t.start()
 try:
  with sync_playwright() as pw, pw.chromium.launch(chromium_sandbox=True) as b:
   pg=b.new_page(viewport={'width':844,'height':390},device_scale_factor=1)
   pg.add_init_script('('+OBSERVER+')()')
   record['browser']=b.version;record['firmware']=manifest['firmware'];record['kernel']=manifest['kernel'];record['rows']=rows
   try:
    app.check_page(pg,f'http://127.0.0.1:{srv.server_port}/emu/',manifest,fixtures)
    record['currentCleanup']=assert_cleanup(pg,running=True)
    record['result']='PASS'
    if mode=='green':
     # Once the documented quiet period really elapses, the unchanged engine
     # clears its unsaved marker; capture the independent certified raw result.
     before_idle=pg.evaluate("Number(document.querySelector('#lcd').dataset.time)")
     pg.wait_for_function("start=>Number(document.querySelector('#lcd').dataset.time)>start+4500",arg=before_idle)
     import base64,io,hashlib
     from PIL import Image
     data=base64.b64decode(pg.locator('#lcd').evaluate("c=>c.toDataURL('image/png').split(',')[1]"))
     (run/'after-real-autosave.png').write_bytes(data)
     record['afterQuietFrame']=hashlib.sha256(app.rgb565(Image.open(io.BytesIO(data)),browser=True)).hexdigest()
     assert record['afterQuietFrame']=='ea4ed289f833912c2d1e75f5da807af4bc7dcc3cdbbfc320be2648ca977e2d99'
     # Retain the second, separately pinned emulator and prior native HTML images.
     previous=root/'tests/fixtures/emulator-lcd-06bd40'
     app.check_page(pg,f'http://127.0.0.1:{srv.server_port}/emu/previous/',json.loads((previous/'frames.json').read_text()),previous)
     record['previousCleanup']=assert_cleanup(pg,running=True)
     app.check_historical_reference(pg,f'http://127.0.0.1:{srv.server_port}',json.loads((site/'APPROVED-PRESENTATION.json').read_text()))
   except Exception as e:record['result']='FAIL';record['error']=str(e);raise
   finally:(run/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 finally:srv.shutdown();t.join()
