from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer
from threading import Thread
import hashlib, importlib.util, json, os, sys
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parent;w=p.parents[1]
label=sys.argv[1]
f=Path(os.environ.get('LCD_CANDIDATE', w/'original-work/lcd/candidate/tests/emulator-lcd-browser.py'))
spec=importlib.util.spec_from_file_location('review_lcd',f)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
site=w/'nightly/.output/product-site';fixtures=w/'nightly/tests/fixtures/emulator-lcd-61827a';manifest=json.loads((fixtures/'frames.json').read_text())
assert hashlib.sha256((site/'emu/kernel.wasm').read_bytes()).hexdigest()==manifest['wasm_sha256']
report={'candidateSha256':hashlib.sha256(f.read_bytes()).hexdigest(),'wasm':manifest['wasm_sha256'],'cases':[]}
m.STATES=m.STATES[:2];check=m.check_frame
def evaluate(page):
 return page.evaluate("""() => ({
     restoredPrototype: AudioContext.prototype.resume===window.savedResume,
     referenceExists: Object.hasOwn(window,'lcdTestAudio') || Object.hasOwn(window,'lcdTestClock'),
     contextState: window.observedLCDContext?.state,
     simTime: Number(document.querySelector('#lcd').dataset.time)||0,
     pressed: document.querySelectorAll('button.held').length,
     status: document.querySelector('#status').textContent,
     transport: document.querySelector('#transport').textContent,
     audioTime: window.observedLCDContext?.currentTime
 })""")
with ThreadingHTTPServer(('127.0.0.1',0), partial(m.QuietHandler,directory=str(site))) as server, sync_playwright() as pw:
 t=Thread(target=server.serve_forever,daemon=True);t.start();base=f'http://127.0.0.1:{server.server_port}'
 b=pw.chromium.launch(chromium_sandbox=True);report['browser']=b.version
 for case in ('success','comparison failure','startup failure'):
  ctx=b.new_context(viewport={'width':844,'height':390},device_scale_factor=1);pg=ctx.new_page()
  pg.add_init_script("""const nativeContext = window.AudioContext;
    window.AudioContext=class extends nativeContext {constructor(...a){super(...a);window.observedLCDContext=this;}};
    window.savedResume=AudioContext.prototype.resume;""")
  pg.set_default_timeout(10000)
  if case=='startup failure':
   # An unstarted production page produces no AudioContext.resume call.
   pg.route('**/emu/page.mjs',lambda r:r.abort());pg.set_default_timeout(1500)
  def sample(*a):
   check(*a)
   if case=='comparison failure' and a[0]=='fx':
    raise AssertionError('injected failure immediately after authentic FX comparison')
  m.check_frame=sample
  rec={'case':case}
  try:m.check_page(pg,base+'/emu/',manifest,fixtures)
  except Exception as e:rec['error']=str(e)[:200]
  rec['onReturn']=evaluate(pg)
  pg.wait_for_timeout(420)
  rec['later']=evaluate(pg)
  print(case,rec,flush=True)
  report['cases'].append(rec);(p/(label+'.json')).write_text(json.dumps(report,indent=2)+'\n')
  ctx.close()
 b.close();server.shutdown();t.join()
