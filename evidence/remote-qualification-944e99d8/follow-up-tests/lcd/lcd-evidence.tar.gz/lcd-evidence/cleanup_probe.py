"""Observe the real clock and its prototype independently from the LCD test."""
OBSERVER = """() => {
    const proto = AudioContext.prototype;
    const initial = Object.getOwnPropertyDescriptor(proto, 'resume');
    const method = proto.resume;
    const previous = proto.createGain;
    let context = null;
    proto.createGain = function(...args) {
        context = this;
        return previous.apply(this, args);
    };
    window.getClockProof = () => {
        const now = Object.getOwnPropertyDescriptor(proto, 'resume');
        const attrs = desc => desc && [desc.enumerable, desc.configurable, desc.writable];
        return {
            methodRestored: proto.resume === method,
            descriptorRestored: JSON.stringify(attrs(initial)) === JSON.stringify(attrs(now)),
            testReferenceRemoved: !Object.hasOwn(window, 'lcdTestClock'),
            audioState: context?.state ?? null,
            elapsed: context?.currentTime ?? null
        };
    };
}"""

def assert_cleanup(page, *, running):
    status = page.evaluate('window.getClockProof()')
    assert all(status[k] for k in ('methodRestored','descriptorRestored','testReferenceRemoved')), status
    assert status['audioState'] == ('running' if running else None), status
    if running:
        page.wait_for_function('start => window.getClockProof().elapsed > start', arg=status['elapsed'])
        status['verifiedClockAdvanced'] = True
    return status
