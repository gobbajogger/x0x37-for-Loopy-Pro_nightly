import asyncio,ast,hashlib,json,subprocess,sys
from pathlib import Path
from playwright.async_api import async_playwright,expect
root=Path(__file__).resolve().parent.parent;product=root/'qual-release';repo=root/'nightly';path='tests/product-remote/native-mix-browser.py';checked='7c59dad5df087994c0d344ffb190be4121cc76d4'
source=subprocess.check_output(['git','-C',str(repo),'show',checked+':'+path]);ns={'__file__':str(product/path),'__name__':'feedback_case'};exec(compile(source,path,'exec'),ns)
recorder,=[n.args[0].value for n in ast.walk(ast.parse(source)) if isinstance(n,ast.Call) and getattr(n.func,'attr',None)=='add_init_script' and n.args and isinstance(n.args[0],ast.Constant) and 'window.controlPackets' in n.args[0].value]
async def run(origin):
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(chromium_sandbox=True)
  try:
   for width,height in [(1440,900),(390,844),(844,390)]:
    context=await browser.new_context(viewport={'width':width,'height':height},has_touch=True);page=await context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    try:
     await page.add_init_script(recorder);await page.goto(origin+'/remote/',wait_until='networkidle');await page.locator('[data-view="mix"]').click();await page.locator('.mixer-fader').first.wait_for()
     await page.locator('.overflow summary').click();await page.locator('#emulator-start').click();await expect(page.locator('#status')).to_contain_text('Emulator running',timeout=20000);await page.locator('.overflow summary').click();await page.locator('[data-mix-source="emulator"]').click();await page.wait_for_function('controlPackets.length>0');base=await page.evaluate('controlPackets.at(-1).controls');await page.locator('[data-mix-mode="fx"]').click()
     target=page.locator('[data-runtime-key="4:0:9"]');await target.press('Enter');field=page.locator('#parameter-value');await expect(field).to_have_value('52');n=await page.evaluate('controlPackets.length');await field.fill('53');await field.press('Tab');await page.wait_for_function('n=>controlPackets.length>n',arg=n);expected=[dict(c,value=53) if (c['target'],c['voice'],c['parameter'])==(4,0,9) else c for c in base];assert await page.evaluate('controlPackets.at(-1).controls')==expected;await expect(target.locator('output')).to_have_text('35%');await page.locator('#undo').click();await page.wait_for_function('n=>controlPackets.length>n',arg=n+1);assert await page.evaluate('controlPackets.at(-1).controls')==base
     await ns['check_feedback_boundary'](page,base);assert await page.evaluate('midiCalls')==0 and not errors,errors;print(json.dumps({'viewport':[width,height],'controls':len(base),'rawSequence':[52,53,52,54,52],'feedbackReadouts':['35%','35%','35%','36%','35%'],'pageErrors':errors,'midiCalls':0}),flush=True)
    finally:await context.close()
  finally:await browser.close()
with ns['core'].server(product/'.output/product-site') as origin:asyncio.run(run(origin))
