"""Run unchanged viewport cases independently with read-only diagnostics on a timed-out Undo."""
import json
import os
from pathlib import Path
from time import monotonic
from playwright.async_api import Locator
runner = Path(__file__).with_name('run.py')
diagnostic_dir = runner.parent/'diagnostics'
width, height = map(int, os.environ['NATIVE_DIAG_SIZE'].split('x'))
diagnostic_dir.mkdir(exist_ok=True)
raw_click = Locator.click
read_state = """el=>{
 const r=el.getBoundingClientRect(), p=[r.left+r.width/2,r.top+r.height/2];
 let n=document.elementFromPoint(...p);
 return {clock:performance.now(),window:[innerWidth,innerHeight,scrollX,scrollY],visibility:document.visibilityState,
    active:document.activeElement?.outerHTML.slice(0,95),button:el.outerHTML.slice(0,210),rect:[r.x,r.y,r.width,r.height],
    style:[getComputedStyle(el).visibility,getComputedStyle(el).display,getComputedStyle(el).pointerEvents],
    pointHit:n?.closest('button')?.id??n?.tagName,request:soundRequests.at(-1),receipt:soundPackets.at(-1)?.undoToken,
    nativeTime:nativeFrames.at(-1)?.time,htmlWidth:document.documentElement.scrollWidth};
}"""
async def observe_click(self, *args, **kwargs):
    if self._impl_obj._selector != '#undo':
        return await raw_click(self,*args,**kwargs)
    start = monotonic()
    before = await self.evaluate(read_state)
    try:
        return await raw_click(self, *args, **kwargs)
    except Exception:
        result = {'before':before,'elapsed':monotonic()-start,'after':await self.evaluate(read_state)}
        print('UNDO_TIMEOUT',json.dumps(result),flush=True)
        raise
Locator.click = observe_click
source=runner.read_text()
assert source.count('suite.main()') == 1
source=source.replace('suite.main()', '''suite.SIZES=[(width,height)]
suite.main()''')
exec(compile(source,str(runner),'exec'))
