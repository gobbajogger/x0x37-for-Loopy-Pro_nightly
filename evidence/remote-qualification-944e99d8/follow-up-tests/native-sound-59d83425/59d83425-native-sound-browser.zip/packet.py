"""Package complete run histories with separate terminal exits and proofs."""
from collections import Counter
import hashlib,json,subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
out=Path(__file__).resolve().parent
repo=out.parent/'glyph-integrated'
head=subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip()
assert head=='59d8342569d494dc587cafde456ed71b5130978d'
assert not subprocess.check_output(['git','-C',repo,'status','--porcelain'])
packet=out/'59d83425-native-sound-browser.zip'
record={'source':head,'harnessSha256':hashlib.sha256((repo/'tests/product-remote/native-sound-browser.py').read_bytes()).hexdigest(),
        'provider':json.loads((repo/'.output/product-site/emu/runtime.json').read_text()),
        'assets':303,'buildValidation':'Unmodified builder --check authenticated the existing product. All original provider checks and exercise cases were retained.',
        'productModified':False,'runs':[]}
def inspect(p):
    data=json.loads(p.read_text())
    if p.name=='proof.json':
        return {'result':'passed','file':p.relative_to(out).as_posix(),'controls': data['controls'],'edits': data['nativeHistory']['edits'],'undoDepth': data['nativeHistory']['undoDepth'],'draftSoundUndoRedoSlots':data['draftSoundUndoRedoSlots'],'draftSha256':data['draftSha256'],'midiCalls':data['midiCalls'],'requests':len(data['requests']),'providerNegativeCaseCodes':dict(Counter(e['code'] for e in data['errors']))}
    e=data.get('exception','')
    last=(data.get('requests') or [{}])[-1]
    return {'result':'failed','file':p.relative_to(out).as_posix(),'exception':e.splitlines()[0] if e else None,'status':data.get('status'),'pageErrors':data.get('pageErrors'),'requests':len(data.get('requests',[])),'lastRequest':{k:last[k] for k in ('op','voice','parameter','request') if k in last},'lastProviderError':(data.get('errors') or [None])[-1]}
record['runs'].append({'kind':'unfiltered original','command':'python -u run.py','viewportOrder':['1440x900','390x844','844x390'],'exit':int((out/'original/exit').read_text()),'startUTC':(out/'original/start').read_text().strip(),'endUTC':(out/'original/end').read_text().strip(),'results':[inspect(f) for f in sorted((out/'original/native-sound').rglob('*.json'))]})
for kind,folder in [('instrumented diagnostic','diagnostics'),('final unmodified single-size','final')]:
    for size in ('390x844','844x390'):
        directory=out/folder/size
        files=sorted(directory.glob('*.json'))
        code=out/f'{size}.exit' if folder=='diagnostics' else directory/'exit'
        entry={'kind':kind,'viewport':size,'exit':int(code.read_text()),'results':[inspect(f) for f in files]}
        if folder=='final':
            entry.update(startUTC=(directory/'start').read_text().strip(),endUTC=(directory/'end').read_text().strip())
        record['runs'].append(entry)
(out/'summary.json').write_text(json.dumps(record,indent=2)+'\n')
lines=[
    '# Native Sound browser verification',
    '',
    f'Product commit `{head}`. The standard build checker verified all 303 shipped assets before each attempt. The test used the published WASM and AudioWorklet through Chromium. It did not operate physical hardware.',
    '',
    '| Run | Viewport | Exit | Result |',
    '| --- | --- | ---: | --- |',
]
for run in record['runs']:
    label=run['kind']
    if label=='unfiltered original':
        outcome={r['file'].split('/')[-2]:r['result'] for r in run['results']}
        description=', '.join(f"{size} {outcome.get(size, 'unreached')}" for size in run['viewportOrder'])
        lines.append(f"| {label} | all three | {run['exit']} | {description} |")
    else:
        result=run['results'][0]
        description=result['result'] if result['result']=='passed' else result['exception']
        lines.append(f"| {label} | {run['viewport']} | {run['exit']} | {description} |")
lines.extend(['', 'The full invocation stopped on its first failed viewport. Each final single-size run executes the same viewport case with its original Playwright actions and deadlines. The separate diagnostic runs instrumented the Undo selector and are recorded independently.', '',
    'Each passing proof records 40 scalar controls, parameter 17 at both ends for both voices, 17 native edits, 16 native Undo operations, unchanged Draft export bytes after Undo and Redo in both slots, and zero Web MIDI calls. Raw screenshots, requests and proof data are stored under the corresponding run.', '',
    'To reproduce, build this commit with the pinned provider, set the same provider and Playwright environment variables, and invoke `python3 tests/product-remote/native-sound-browser.py` from its root. The included `run.py` reuses a byte-checked product build. `final-size.py` selects a single published case. The provider identities and duration of each recorded run appear in `summary.json`.'])
(out/'README.md').write_text('\n'.join(lines)+'\n')
items=[out/x for x in ['README.md','run.py','diagnostic.py','final-size.py','final-sizes.sh','load-sample.py','summary.json','load-window.log','packet.py','390x844.log','390x844.exit','844x390.log','844x390.exit']]
for key in ('original','diagnostics','final'):
    items.extend(p for p in (out/key).rglob('*') if p.is_file())
with ZipFile(packet,'w',compression=ZIP_DEFLATED) as z:
    for p in sorted(items): z.write(p, p.relative_to(out).as_posix())
with ZipFile(packet) as z:
    assert z.testzip() is None
print(packet, packet.stat().st_size, hashlib.sha256(packet.read_bytes()).hexdigest())
