"""Run the shipped native Sound entrypoint with its clean, verified product output."""
from contextlib import nullcontext
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import subprocess
from types import SimpleNamespace

root=Path.cwd()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='59d8342569d494dc587cafde456ed71b5130978d'
assert not subprocess.check_output(['git','status','--porcelain'])
site=root/'.output/product-site'
path=root/'tests/product-remote/native-sound-browser.py'
spec=importlib.util.spec_from_file_location('native_sound',path)
suite=importlib.util.module_from_spec(spec)
spec.loader.exec_module(suite)
assert suite.SIZES==[(1440,900),(390,844),(844,390)]
def existing_product(*,prefix,dir):
    assert prefix=='native-sound-' and Path(dir)==root/'.output'
    return nullcontext(str(site))
def verify_build(args,*,cwd,check):
    assert args==['node','scripts/build-product-site.mjs','--output',str(site)] and cwd==root and check is True
    result=subprocess.run([*args,'--check'],cwd=cwd,check=True,text=True,stdout=subprocess.PIPE)
    manifest=json.loads(result.stdout)
    assert manifest['files']==303 and manifest['emulator'] and not manifest['firmwareWrites']
    assert manifest['catalogMutations']==[]
    print('Verified existing product',result.stdout.strip(),flush=True)
    return result
print('Frozen test',head,'native-sound-browser.py sha256',sha256(path.read_bytes()).hexdigest(),flush=True)
# main retains all provider/kernel/PCM checks, its original server and the
# complete unmodified cases loop. Only the output-directory/build pair is reused.
suite.tempfile=SimpleNamespace(TemporaryDirectory=existing_product)
suite.subprocess=SimpleNamespace(run=verify_build)
suite.main()
