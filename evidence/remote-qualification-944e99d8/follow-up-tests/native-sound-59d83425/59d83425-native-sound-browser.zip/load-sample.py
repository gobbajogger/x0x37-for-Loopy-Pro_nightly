"""Observe worker pressure without running a browser."""
import os, time
from datetime import datetime, timezone
from pathlib import Path
def values():
    return list(map(int,Path('/proc/stat').read_text().splitlines()[0].split()[1:9]))
previous = values()
for _ in range(4):
    time.sleep(15)
    current=values()
    delta=[a-b for a,b in zip(current,previous)]; n=sum(delta) or 1
    print(datetime.now(timezone.utc).isoformat(timespec='seconds'), f'load1={os.getloadavg()[0]:.2f} idle={delta[3]/n:.1%} steal={delta[7]/n:.1%}',flush=True)
    previous=current
