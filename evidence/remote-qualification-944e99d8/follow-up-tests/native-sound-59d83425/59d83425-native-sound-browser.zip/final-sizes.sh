#!/usr/bin/env bash
set -u
out=$(cd ../native-sound-59d83425 && pwd)
source ../../environment/qualification-env.sh
for size in 390x844 844x390; do
  round="$out/final/$size"
  mkdir -p "$round"
  date -u +%FT%TZ > "$round/start"
  NATIVE_SIZE="$size" python -u "$out/final-size.py" > "$round/terminal.log" 2>&1
  result=$?
  echo "$result" > "$round/exit"
  date -u +%FT%TZ > "$round/end"
  if [[ -d "test-results/native-sound/$size" ]]; then cp -a "test-results/native-sound/$size/." "$round/"; fi
done
python "$out/packet.py"
