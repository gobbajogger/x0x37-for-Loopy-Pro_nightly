"""Run one frozen viewport with the published harness and default timeouts."""
import os
from pathlib import Path
width, height = map(int, os.environ['NATIVE_SIZE'].split('x'))
assert (width, height) in ((390, 844), (844, 390))
runner = Path(__file__).with_name('run.py')
source = runner.read_text()
assert source.count('suite.main()') == 1
source = source.replace('suite.main()', 'suite.SIZES = [(width, height)]\nsuite.main()')
exec(compile(source, str(runner), 'exec'))
