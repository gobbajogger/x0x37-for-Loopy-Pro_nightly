import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { withStatusFixture } from './tree/tests/fixtures/status-fixture.mjs';
const external=fs.mkdtempSync(join(tmpdir(),'status-outside-'));
const marker=join(external,'untouched');fs.writeFileSync(marker,'outside');
const entries=new Map([['plain',Buffer.from('abc')],['a/b/other',Buffer.from('def')],['a/file',Buffer.alloc(0)]]);
let cleaned;
try {
 await assert.rejects(withStatusFixture(entries, async(dir,reset)=>{
  cleaned=dir;reset();
  const initial=fs.statSync(join(dir,'plain')).ino;
  fs.writeFileSync(join(dir,'plain'),'xyz');fs.rmSync(join(dir,'a/b'),{recursive:true});
  fs.writeFileSync(join(dir,'extra'),'delete');fs.mkdirSync(join(dir,'old-directory'));fs.symlinkSync(marker,join(dir,'old-directory/link'));
  reset();assert.equal(fs.statSync(join(dir,'plain')).ino,initial);assert.deepEqual(fs.readdirSync(dir).sort(),['a','plain']);assert.equal(fs.readFileSync(join(dir,'a/b/other'),'utf8'),'def');
  fs.rmSync(join(dir,'plain'));fs.linkSync(marker,join(dir,'plain'));fs.rmSync(join(dir,'a'),{recursive:true});fs.symlinkSync(external,join(dir,'a'),'dir');
  reset();assert.equal(fs.readFileSync(marker,'utf8'),'outside');assert.equal(fs.statSync(join(dir,'plain')).nlink,1);assert.equal(fs.readFileSync(join(dir,'plain'),'utf8'),'abc');assert.equal(fs.statSync(join(dir,'a')).isDirectory(),true);
  fs.rmSync(dir,{recursive:true});fs.symlinkSync(external,dir,'dir');reset();assert.equal(fs.readFileSync(marker,'utf8'),'outside');assert.equal(fs.lstatSync(dir).isDirectory(),true);
  await withStatusFixture(entries,async(other,restore)=>{restore();assert.notEqual(other,dir);fs.writeFileSync(join(other,'plain'),'different');assert.equal(fs.readFileSync(join(dir,'plain'),'utf8'),'abc')});
  fs.rmSync(join(dir,'plain'));fs.mkdirSync(join(dir,'plain'));reset();assert.equal(fs.readFileSync(join(dir,'plain'),'utf8'),'abc');
  throw Error('deliberate verifier rejection');
 }),/deliberate verifier rejection/);
 assert.equal(fs.existsSync(cleaned),false);
 console.log('PASS pristine and equal-length bytes, inode reuse, empty and deleted files, nested extras, file/directory reversal, protected symlink and hardlink targets, replaced root, overlapping private runs, exception propagation and final cleanup');
} finally {fs.rmSync(external,{recursive:true,force:true});}
