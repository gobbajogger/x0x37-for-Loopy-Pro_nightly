const fs=require('node:fs'),path=require('node:path'),mod=require('node:module');
const stats={tempRoots:0,mkdirCalls:0,createdDirs:0,copies:0,copiedBytes:0,writes:0,writtenBytes:0};
const tmp=process.env.TMPDIR+path.sep;
for(const op of ['mkdtempSync','mkdirSync','copyFileSync','writeFileSync']){
 const original=fs[op];
 fs[op]=function(...args){
  const file=op==='copyFileSync'?args[1]:args[0];
  if(typeof file==='string'&&file.startsWith(tmp)){
   if(op==='mkdtempSync'){stats.tempRoots++;stats.createdDirs++}
   if(op==='mkdirSync'){stats.mkdirCalls++;let p=file;while(!fs.existsSync(p)){stats.createdDirs++;p=path.dirname(p);}}
   if(op==='copyFileSync'){stats.copies++;stats.copiedBytes+=fs.statSync(args[0]).size;}
   if(op==='writeFileSync'){stats.writes++;stats.writtenBytes+=Buffer.byteLength(args[1]);}
  }
  return original.apply(this,args);
 }
}
mod.syncBuiltinESMExports();process.on('exit',()=>fs.writeFileSync(process.env.STATS,JSON.stringify(stats,null,2)+'\n'));
