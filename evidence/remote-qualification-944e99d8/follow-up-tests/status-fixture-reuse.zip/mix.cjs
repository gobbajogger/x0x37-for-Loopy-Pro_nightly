const fs=require('node:fs'), v=require('node:vm'),path=require('node:path');
const source=fs.readFileSync('delivery/tests/build-status-negatives.test.mjs','utf8');
const baseline=new Map();
const required=eval(source.match(/const required = (\[[^;]+\]);/)[1]);
for(const f of required)baseline.set(f,fs.readFileSync('delivery/'+f));
baseline.set('package.json',Buffer.from('{"type":"module"}\n'));
const dir='private';
const mem=new Map();
let write=0;
const fp=p=>path.relative(dir,p);
const fake={readFileSync(p,enc){const val=mem.get(fp(p))??baseline.get(fp(p));return enc?val.toString(enc):val;},writeFileSync(p,b){const bytes=Buffer.from(b);mem.set(fp(p),bytes);write+=bytes.length;},appendFileSync(p,b){mem.set(fp(p),Buffer.concat([this.readFileSync(p),Buffer.from(b)]));write+=Buffer.byteLength(b);}};
const cases=[];
const env={assert:require('node:assert/strict'),JSON,structuredClone,Buffer,URL,join:path.join,console:{log:()=>{}},fs:fake,run:(label,mutate,pass=false)=>cases.push({label,mutate,pass})};
const body=source.slice(source.indexOf('const edit =')).replaceAll('await runCases();','');
Function(...Object.keys(env),body)(...Object.values(env));
let minimum=Infinity, maximum=0, largestCase;
let changedFiles=0,changedBytes=0,savedBetween=0,prev=new Map();
const names=new Map();
for(const {label,mutate} of cases){mem.clear();mutate(dir);for(const [f,data] of mem){
 if(!data.equals(baseline.get(f))){changedFiles++;names.set(f,(names.get(f)||0)+1);changedBytes+=baseline.get(f).length;}
}
for(const [f,b] of baseline)if((prev.get(f)||b).equals(mem.get(f)||b))savedBetween+=(mem.get(f)||b).length;
const caseBytes=[...baseline].reduce((n,[f,b])=>n+(mem.get(f)||b).length,0); minimum=Math.min(minimum,caseBytes);if(caseBytes>maximum){maximum=caseBytes;largestCase=label}
prev=new Map(mem);
}
const total=[...baseline.values()].reduce((n,b)=>n+b.length,0);
console.log(JSON.stringify({cases:cases.length,minimum,maximum,largestCase,files:[...names],bytes:total,baseline:total*cases.length,write,restores:changedFiles,restoreBytes:changedBytes,unchangedWhenBackToBack:savedBetween,folders:[...new Set([...baseline.keys()].map(f=>path.dirname(f)))]},null,2));
