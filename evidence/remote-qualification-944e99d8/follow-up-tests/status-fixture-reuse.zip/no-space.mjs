import assert from 'node:assert/strict';
import fs from 'node:fs';
import {syncBuiltinESMExports} from 'node:module';
import {withStatusFixture} from './tree/tests/fixtures/status-fixture.mjs';
const original=fs.writeFileSync;
const full=Object.assign(new Error('injected full filesystem'),{code:'ENOSPC'});
let dir;
try {
 fs.writeFileSync=()=>{throw full};syncBuiltinESMExports();
 await assert.rejects(withStatusFixture(new Map([['file',Buffer.from('contents')]]),async(d,reset)=>{dir=d;reset()}),error=>error===full);
 assert.equal(fs.existsSync(dir),false);
} finally {fs.writeFileSync=original;syncBuiltinESMExports();}
console.log('PASS injected ENOSPC propagated as the same error and the private root was removed');
