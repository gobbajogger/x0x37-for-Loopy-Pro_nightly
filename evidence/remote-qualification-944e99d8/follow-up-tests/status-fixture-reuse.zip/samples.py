from pathlib import Path
base=Path('nativework/status-reuse'); tree=base/'tree'; tests=tree/'tests'
labels=['baseline','historic-elite-firmware-hash-forged-64hex','historic-pro-firmware-hash-forged-64hex','nonempty-preview','source-docs-mismatch','r16-immutable-five-audit-proof-fields-positive','r48-unapproved-firmware-download-HREF']
import json
for n,src in [('old',Path('delivery/tests/build-status-negatives.test.mjs')),('new',tests/'build-status-negatives.test.mjs')]:
 s=src.read_text().replace('  cases.push(',f'  if(!new Set({json.dumps(labels)}).has(label))return;\n  cases.push(',1)
 s=s.replace('import { runNodeCli }', 'import { runNodeCli as originalRunNodeCli }')
 s=s.replace('const root =',"""import {createHash} from 'node:crypto';
async function runNodeCli(path,args,opts) {
  const bytes = Object.fromEntries([...required,'package.json'].sort().map(p=>[p,createHash('sha256').update(fs.readFileSync(join(opts.cwd,p))).digest('hex')]));
  const result = await originalRunNodeCli(path,args,opts);
  console.log(JSON.stringify({label:opts.label,status:result.status,assertion:result.stderr.includes('AssertionError'),bytes}));
  return result;
}
const root =""")
 (tests/f'sample-{n}.mjs').write_text(s)
