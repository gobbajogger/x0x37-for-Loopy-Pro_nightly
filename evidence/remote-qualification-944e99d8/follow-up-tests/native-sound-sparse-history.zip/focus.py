"""Run the patch's authoring and history assertions on immutable, built 16af product UI."""
import asyncio, hashlib, json, runpy, subprocess, textwrap, time, traceback
from pathlib import Path
from playwright.async_api import async_playwright, expect

d=Path(__file__).resolve().parent
workspace=d.parents[1]
tree=workspace/'qual-next'
base='16afbf2d100bd255190f9fa6f5d9dd2749b7e618'
target='tests/product-remote/native-sound-browser.py'
repo=workspace/'nightly'
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
original=git('show',base+':'+target)
assert original==(d/'base'/target).read_bytes() and (tree/target).read_bytes()==original
patched=(d/'patch'/target).read_text()
ns=runpy.run_path(str(tree/target))
fixture=tree/target
archived=json.loads((fixture.parent/'fixtures/legacy-sound-banks/both-owners.json').read_text())
site=d/'site'
files=git('ls-tree','-r','-z',base,'--','web/product-site/remote').decode().split('\0')
for ls in files:
    if ls:
        meta,name=ls.split('\t');sha=meta.split()[2];b=(site/name.removeprefix('web/product-site/')).read_bytes()
        assert hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()==sha,name
def between(left,right):
    return textwrap.dedent(patched[patched.index(left):patched.index(right,patched.index(left))])
helper=between('def parameter_overrides','async def native_elapsed')
author=between('                    authored = []','                    endpoint_proof = []')
history=between("                    await page.locator('#undo').click()\n                    await expect(page.locator('[data-note", "                    assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')")
assert 'assert parameter_overrides(saved) == expected_overrides' in history
history=history.replace('        assert parameter_overrides(saved) == expected_overrides',
                        '        assert parameter_overrides(saved) == expected_overrides\n        checks.append(dict(direction=direction, slot=change["part"], uiValues=dict(draft_values), exported=parameter_overrides(saved)))')
assert 'checks.append(' in history
exec(helper+'\nasync def exercise(page,checks):\n'+textwrap.indent(author+history+'return authored, draft\n','    '),ns)
report=dict(commit=base,changedTestSha256=hashlib.sha256(patched.encode()).hexdigest(),sourceRemoteFilesVerified=len(files)-1,kernelSha256=hashlib.sha256((site/'emu/kernel.wasm').read_bytes()).hexdigest(),scenarios=[])
def write(): (d/'focused-results.json').write_text(json.dumps(report,indent=2)+'\n')
async def go(origin):
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(chromium_sandbox=True)
  report['browser']=browser.version
  seeds=[]
  for case in ('absent','present'):
   ctx=await browser.new_context(viewport={'width':1440,'height':900},accept_downloads=True,has_touch=True)
   page=await ctx.new_page(); errs=[]; page.on('pageerror',lambda exc:errs.append(str(exc)))
   source={**archived,'parameters':seeds.copy()}
   run={'case':case,'imported':source['parameters'],'uiAndFileChecks':[]}
   report['scenarios'].append(run);write()
   try:
    await page.goto(origin+'/remote/',wait_until='networkidle')
    await page.locator('#draft-file').set_input_files({'name':'both-owners.json','mimeType':'application/json','buffer':json.dumps(source).encode()})
    await page.locator('#draft-replace').click()
    authored,final_bytes=await ns['exercise'](page,run['uiAndFileChecks'])
    assert len(run['uiAndFileChecks'])==4 and not errs
    run.update(finalDraftBytesRestored=True,finalDraftSha256=hashlib.sha256(final_bytes).hexdigest(),authored=authored,pageErrors=errs,passed=True)
    if case=='absent':
     # Retain an explicit baseline, a non-baseline override and a third unrelated entry.
     seeds=[{'id':authored[0]['id'],'value':authored[0]['before']},{'id':authored[1]['id'],'value':authored[1]['value']}]
     await page.locator('[data-engine="miami"]').click()
     await page.locator('[data-view="sound"]').click()
     other=page.locator('.source-sound-list button[data-param]').nth(1)
     other_id=await other.get_attribute('data-param')
     assert other_id not in {v['id'] for v in seeds}
     await other.press('Enter')
     field=page.locator('#parameter-value')
     value=float(await field.input_value()); step=float(await field.get_attribute('step'))
     maximum=float(await field.get_attribute('max'))
     seeds.append({'id':other_id,'value':value+(-step if value==maximum else step)})
    print('PASS',case,len(run['uiAndFileChecks']),'Undo/Redo exports; two displayed slot values each; final bytes restored; 0 page errors',flush=True)
   except Exception:
    run['failure']=traceback.format_exc();run['pageErrors']=errs;print(run['failure'],flush=True)
    raise
   finally:
    write();await ctx.close()
  await browser.close()
start=time.monotonic()
try:
 with ns['core'].server(site) as origin: asyncio.run(go(origin))
finally:
 report['elapsedSeconds']=round(time.monotonic()-start,2);write()
