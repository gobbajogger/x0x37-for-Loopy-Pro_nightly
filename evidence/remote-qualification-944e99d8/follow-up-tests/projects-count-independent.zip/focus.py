from pathlib import Path
import asyncio, hashlib, json, os, subprocess, sys, traceback, time
from playwright.async_api import async_playwright, expect
d=Path(__file__).resolve().parent
w=d.parents[1];target='tests/product-remote/funkybeats-browser.py'
base='59d8342569d494dc587cafde456ed71b5130978d'
site=Path(os.environ.get('DNBOX_FOCUS_SITE',w/'edge-work/glyph-integrated/.output/product-site'))
repo=w/'nightly'
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
assert git('show',base+':'+target)==(d/'funkybeats-base.py').read_bytes()
states=git('ls-tree','-r','-z',base,'--','web/product-site/remote').decode().split('\0')[:-1]
for ls in states:
 meta,name=ls.split('\t'); b=(site/name.removeprefix('web/product-site/')).read_bytes()
 assert hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()==meta.split()[2]
mode=sys.argv[1];assert mode in ('base','patched')
text=(d/f'funkybeats-{mode}.py').read_bytes()
namespace={'__file__':str(d/f'funkybeats-{mode}.py'),'__name__':'isolated_funkybeats'}
exec(compile(text,target,'exec'),namespace)
namespace['SOURCE']=site;namespace['preload_product'](site)
report={'commit':base,'mode':mode,'testSha256':hashlib.sha256(text).hexdigest(),'remoteGitBlobs':len(states),'sandbox':True,'states':[],'errors':[]}
def save(): (d/(mode+'-results.json')).write_text(json.dumps(report,indent=2)+'\n')
def observed(*args,**kwargs):
 if args and args[0]=='PROJECT_SOUND_COUNT':
  report['states'].append(dict(width=args[1],height=args[2],state=args[3],**json.loads(args[4])));save()
 print(*args,**kwargs)
namespace['print']=observed
async def exercise():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(chromium_sandbox=True);report['browser']=browser.version
  try:
   ctx=await browser.new_context(viewport={'width':844,'height':390},has_touch=True)
   await ctx.route('**/*',namespace['serve'])
   page=await ctx.new_page();page.on('pageerror',lambda e:report['errors'].append(str(e)))
   await page.add_init_script('navigator.requestMIDIAccess=()=>{throw Error("Device access forbidden in local draft test")};')
   await page.goto(namespace['ORIGIN']+'/remote/')
   await page.wait_for_function('document.getElementById("status").textContent.includes("Draft")')
   await namespace['project_sound_edit_count'](page)
   assert not report['errors']
   await ctx.close()
  finally:await browser.close()
start=time.monotonic()
try:
 asyncio.run(exercise());report['passed']=True
except Exception:
 report['passed']=False;report['traceback']=traceback.format_exc();print(report['traceback'],flush=True)
finally:
 report['durationSeconds']=round(time.monotonic()-start,2);save()
raise SystemExit(0 if report['passed'] else 1)
